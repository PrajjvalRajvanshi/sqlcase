Alter table customer add Gender varchar2(1);
Alter table customer add Age Number(3);
Alter table customer add phoneNo(10);
Rename customer to cust_table;