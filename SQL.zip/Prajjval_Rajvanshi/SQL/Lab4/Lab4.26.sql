create table departmentmaster(deptno number(50),Dname varchar2(25),location varchar2(25));
insert into departmentmaster  values(seq_dept.NEXTVAL,'MARKETING','NEW DELHI');
insert into departmentmaster  values(seq_dept.NEXTVAL,'SALES','chennai');
insert into departmentmaster  values(seq_dept.NEXTVAL,'RESEARCH','BOSTON');