CREATE sequence SEQ_DEPT minvalue 40 start with 40
	increment by 10 MAX VALUE 200 cache 40;