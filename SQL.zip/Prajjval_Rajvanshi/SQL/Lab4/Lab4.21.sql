Create table accountdetails as select * from Accountmaster;
