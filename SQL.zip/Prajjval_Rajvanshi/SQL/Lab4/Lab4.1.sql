create table customer
	(
	customerid number(5),
	cust_name varchar2(20),
	Address1 varchar2(30),
	Address2 varchar2(30)
	);