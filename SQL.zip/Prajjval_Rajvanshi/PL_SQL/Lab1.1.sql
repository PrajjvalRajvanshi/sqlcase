last line should be written including not null default-
V_Sample5 NUMBER(2) not null DEFAULT 25;
